// Copy this file as config.js in the same folder, with the proper database connection URI.

module.exports = {
  db: 'mongodb://localhost:20017/Budget',
  db_dev: 'mongodb://localhost:20017/Budget',
};
